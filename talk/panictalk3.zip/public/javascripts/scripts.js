//Função para confirmar alguma ação
var confirmAction = function(idObj){
	return confirm('Are you sure?')
};

